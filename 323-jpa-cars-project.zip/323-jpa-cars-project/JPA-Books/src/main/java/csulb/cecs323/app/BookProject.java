/**
 Main method to run POJOs
 Homework Assignment: JPA - Books
 @author Frank Mancia, Jett Sonoda, Eric Nguyen
 @version 1.01 03/25/2022
 */

package csulb.cecs323.app;

// Import all of the entity classes that we have written for this application.
import csulb.cecs323.model.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.*;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A simple application to demonstrate how to persist an object in JPA.
 * <p>
 * This is for demonstration and educational purposes only.
 * </p>
 * <p>
 *     Originally provided by Dr. Alvaro Monge of CSULB, and subsequently modified by Dave Brown.
 * </p>
 */
public class BookProject {
   /**
    * You will likely need the entityManager in a great many functions throughout your application.
    * Rather than make this a global variable, we will make it an instance variable within the CarClub
    * class, and create an instance of CarClub in the main.
    */
   private EntityManager entityManager;

   /**
    * The Logger can easily be configured to log to a file, rather than, or in addition to, the console.
    * We use it because it is easy to control how much or how little logging gets done without having to
    * go through the application and comment out/uncomment code and run the risk of introducing a bug.
    * Here also, we want to make sure that the one Logger instance is readily available throughout the
    * application, without resorting to creating a global variable.
    */
   private static final Logger LOGGER = Logger.getLogger(BookProject.class.getName());

   /**
    * The constructor for the CarClub class.  All that it does is stash the provided EntityManager
    * for use later in the application.
    *
    * @param manager The EntityManager that we will use.
    */
   public BookProject(EntityManager manager) {
      this.entityManager = manager;
   } //copy constructor for entity manager

   public static void main(String[] args) {
      //LOGGER.setLevel(Level.OFF);
      LOGGER.fine("Creating EntityManagerFactory and EntityManager");
      EntityManagerFactory factory = Persistence.createEntityManagerFactory("BookProject");
      EntityManager manager = factory.createEntityManager();
      // Create an instance of bookProject and store our new EntityManager as an instance variable.
      BookProject bookProject = new BookProject(manager);


      // Any changes to the database need to be done within a transaction.
      // See: https://en.wikibooks.org/wiki/Java_Persistence/Transactions

      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = manager.getTransaction();

      tx.begin();

      //need to create arraylist for authoringEntities
      ArrayList<AuthoringEntities> authoringEntities = new ArrayList<>();
      WritingGroups writingGroups1 = new WritingGroups("The LB Writers", "info@lawriters.com", "Ed Sullivan", 2010);
      authoringEntities.add(writingGroups1);
      AdHocTeams adHocTeams1 = new AdHocTeams("LB AdHocs", "info@lbadhocs.com");
      authoringEntities.add(adHocTeams1);
      IndividualAuthors individualAuthors1 = new IndividualAuthors("Michael Smith", "msmith@gmail.com");
      authoringEntities.add(individualAuthors1);

      //get adhocteam and add indivauth
      adHocTeams1.addIndividualAuthors(individualAuthors1);

      //need to create entity on arraylist
      bookProject.createEntity(authoringEntities);

      //need to create arraylist for Publisher
      ArrayList<Publishers> publishers = new ArrayList<>();
      publishers.add(new Publishers("Book Writing Inc.", "888-586-5175", "info@bookwritinginc.com"));
      publishers.add(new Publishers("323 Writers", "123-423-1525", "info@writers.com"));

      //need to create entity on arraylist
      bookProject.createEntity(publishers);

      //need to create arraylist for Publisher
      ArrayList<Books> books = new ArrayList<>();
      books.add(new Books("9780525620785", "Mexican Goth", 2020, publishers.get(0), authoringEntities.get(0)));

      //need to create entity on arraylist
      bookProject.createEntity(books);

      // Commit the changes so that the new data persists and is visible to other users.
      tx.commit();
      LOGGER.fine("End of Transaction");

      System.out.print("Hello there!");
      bookProject.menu();
      System.out.println("Completed Satisfactorily :)");


   } // End of the main method

   /**
    * Create and persist a list of objects to the database.
    *
    * @param entities The list of entities to persist.  These can be any object that has been
    *                 properly annotated in JPA and marked as "persistable."  I specifically
    *                 used a Java generic so that I did not have to write this over and over.
    */
   public <E> void createEntity(List<E> entities) {
      for (E next : entities) {
         LOGGER.info("Persisting: " + next);
         // Use the CarClub entityManager instance variable to get our EntityManager.
         this.entityManager.persist(next);
      } // list info of entity in the list

      // The auto generated ID (if present) is not passed in to the constructor since JPA will
      // generate a value.  So the previous for loop will not show a value for the ID.  But
      // now that the Entity has been persisted, JPA has generated the ID and filled that in.
      for (E next : entities) {
         LOGGER.info("Persisted object after flush (non-null id): " + next);
      } // end of loop to display logger info in Entity list
   } // End of createEntity member method

   public static int validateInput(String options, int range) {
      boolean validIn; //if the range is valid or not
      int input = Integer.MAX_VALUE; // input becomes the max value in range.
      Scanner sc = new Scanner(System.in);

      do {
         System.out.print(options);
         validIn = true;
         try {
            input = sc.nextInt();

            if (input > range || input <= 0) {
               System.out.println("Sorry that is not a valid option, try again. Please enter a number only.");
               validIn = false;
            } // checks if input is a valid option
         } // end of try
         catch (InputMismatchException e) {
            System.out.println("Sorry that is not a valid option, try again. Please enter a number only.");
            sc.next();
            validIn = false;
         } // end of catch
      } while (!validIn); // ends loop input is not in range.

      return input;
   }

   public boolean findExiting(String queryName, String input) {
      int value = (int) this.entityManager.createNamedQuery(queryName).setParameter(1, "%"+input+"%").getSingleResult(); // find the value with a query search

      return value >= 1 ? true : false;
   }

   public void publisherMenu() {
      System.out.println("\nWould you like to...");
      int userInputInt = validateInput("1. Add Publisher\n2. Find a Publisher\n3. Go Back\n> ", 3); //removed and commented out remove publisher
      if (userInputInt==1) {
         addPublisher();
      } //add publisher
      else if (userInputInt==2) {
         searchPublisher();
      }//find publisher
       else if (userInputInt==3) {
         return;
      } // returns to menu
   } //end of publisher menu

   public void addPublisher() {
      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = entityManager.getTransaction();
      System.out.println("Lets create a new Publisher.");
      Publishers newPublisher = new Publishers();
      newPublisher.setName(getNewPublisherName());
      newPublisher.setEmail(getNewPublisherEmail());
      newPublisher.setPhone(getNewPublisherPhone());
      LOGGER.fine("Beginning of Transaction");
      tx.begin();
      List<Publishers> newPublisherList = new ArrayList<Publishers>();
      newPublisherList.add(newPublisher);
      this.createEntity (newPublisherList);
      tx.commit();
      LOGGER.fine("End of Transaction");
      System.out.println("Publisher successfully added");
   } // end of add Publisher menu

   public String getNewPublisherName() {
      boolean exists; //used to check if value exists in DB
      String userInputString = ""; // used to store user's input
      Scanner sc = new Scanner(System.in);
      do {
         System.out.print("Enter name for Publisher.\n> ");

         userInputString = sc.nextLine();
         exists = this.findExiting("publishersNameExists", userInputString);

         if (exists) System.out.println("This name already exists in our records, try again.");
         if (userInputString.length() <= 1) System.out.println("That name is too long or short, try again.");
      } while (userInputString.length() <= 1 || userInputString.length() > 80 || exists); // checks if user input exist and is within character limits.
      return userInputString;
   } // end of get new publisherName
   public String getNewPublisherEmail() {
      Matcher matcher; // used to validate email and phone entry
      boolean exists; //used to check if value exists in DB
      String userInputString = ""; // used to store user's input
      Scanner sc = new Scanner(System.in);
      do {
         System.out.print("Enter email for Publisher.(ex. test@example.com)\n> ");
         Pattern pattern = Pattern.compile("^(.+)@(.+)$");

         userInputString = sc.nextLine();
         matcher = pattern.matcher(userInputString);
         exists = this.findExiting("publishersEmailExists", userInputString);

         if (!matcher.matches()) System.out.println("That is not a valid email, please try again.");
         if (exists) System.out.println("That email already exists, please enter a new one.");
      } while (!matcher.matches() || userInputString.length() > 80 || exists == true); // check if input exisits and is within character limits
      return userInputString.toLowerCase();
   } // end of getNewPublisherEmail function

   public String getNewPublisherPhone() {
      Matcher matcher; // used to validate email and phone entry
      boolean exists; //used to check if value exists in DB
      String userInputString = ""; // used to store user's input.
      Scanner sc = new Scanner(System.in);
      do {
         System.out.println("Enter phone for publisher.(ex. 123-456-7890)");

         Pattern pattern = Pattern.compile("^(1-)?\\d{3}-\\d{3}-\\d{4}$"); // ^(\d{3})[- .]?\d{3}[- .]?\d{4}$

         userInputString = sc.next();
         matcher = pattern.matcher(userInputString);
         exists = this.findExiting("publishersPhoneExists", userInputString);

         if (!matcher.matches()) System.out.println("That is not a valid phone, please try again.");
         if (exists) System.out.println("That phone already exists, please enter a new one.");
      } while (!matcher.matches() || userInputString.length() > 24 || exists == true); // checks if input exist with list and is within character limits.
      return userInputString;
   } // end of getNewPublisherPhone

   public void searchPublisher() {
      int userInputInt = validateInput("1. Search using name\n2. Search using phone number\n3. Search using email\n4. Go Back\n> ", 4); // stores the user's option
      if (userInputInt==1) {
         searchPublisherName();
      } //search publisher using name
      else if (userInputInt==2) {
         searchPublisherPhone();
      } // search publisher using phone number
      else if (userInputInt==3) {
         searchPublisherEmail();
      } // search using email
      else if (userInputInt==4) {
         return;
      }// return to menu
   } // end of searchPublisher

   public void searchPublisherName() {
      String userInputString = ""; // store user's input
      Scanner sc = new Scanner(System.in);
      do {
         System.out.print("Enter name for Publisher OR enter '0' to go back to menu\n> ");
         userInputString = sc.nextLine();
         if (userInputString.equals("0")) {
            return;
         } // check if user wants to exit
         if (userInputString.length() <= 1) System.out.println("That name is too long or short, try again.");
      } while (userInputString.length() <= 1 || userInputString.length() > 80);
      List<Publishers> publishersList = this.entityManager.createQuery("SELECT p FROM Publishers p WHERE UPPER(p.name) LIKE UPPER(:name)", Publishers.class).setParameter("name", "%"+userInputString+"%").getResultList();
      if (publishersList.isEmpty()) {
         System.out.println("This name is not associated with any Publisher");
         return;
      } // checks if list is empty
      System.out.printf("%-35s %-15s %-15s\n", "Name", "Phone Number", "Email");
      for(Publishers p:publishersList){
         System.out.printf("%-35s %-15s %-15s\n", p.getName(), p.getPhone(), p.getEmail());
      } // display all the date for publisher
   } // end of search publisher name function

   public void searchPublisherPhone() {
      Matcher matcher; // used to validate email and phone entry
      boolean exists; //used to check if value exists in DB
      String userInputString = ""; // stores user's input
      Scanner sc = new Scanner(System.in);
      do {
         System.out.println("Enter phone number.(ex. 123-456-7890) OR enter 'exit' to go back to menu\n>");

         Pattern pattern = Pattern.compile("^(1-)?\\d{3}-\\d{3}-\\d{4}$"); // ^(\d{3})[- .]?\d{3}[- .]?\d{4}$

         userInputString = sc.next();
         if (userInputString.toUpperCase().equals("EXIT")) {
            return;
         } // checks if user wants to exit
         matcher = pattern.matcher(userInputString);
         exists = this.findExiting("publishersPhoneExists", userInputString);

         if (!matcher.matches()) System.out.println("That is not a valid phone, please try again.");
         else if (!exists) System.out.println("This phone number is not associated with any Publisher");
      } while (!matcher.matches() || userInputString.length() > 24 || !exists); // checks if length is corect and exist in list
      List<Publishers> publishersList = this.entityManager.createQuery("SELECT p FROM Publishers p WHERE p.phone LIKE :phone_number", Publishers.class).setParameter("phone_number", userInputString).getResultList();
      System.out.printf("%-35s %-15s %-15s\n", "Name", "Phone Number", "Email");
      for(Publishers p:publishersList){
         System.out.printf("%-35s %-15s %-15s\n", p.getName(), p.getPhone(), p.getEmail());
      } // list all data in publishersList
   } // end of search Publisher phone function

   public void searchPublisherEmail() {
      Matcher matcher; // used to validate email and phone entry
      boolean exists; //used to check if value exists in DB
      String userInputString = ""; // store users data
      Scanner sc = new Scanner(System.in);
      do {
         System.out.print("Enter email for Publisher.(ex. test@example.com) OR enter 'exit' to go back to menu\n> ");
         Pattern pattern = Pattern.compile("^(.+)@(.+)$"); // ^(.+)@(.+)$

         userInputString = sc.nextLine();
         if (userInputString.toUpperCase().equals("EXIT")) {
            return;
         } // checks if the user wants to exit
         matcher = pattern.matcher(userInputString);
         exists = this.findExiting("publishersEmailExists", userInputString);

         if (!matcher.matches()) System.out.println("That is not a valid email, please try again.");
         else if (exists == false) System.out.println("This email is not associated with any Publisher.");
      } while (!matcher.matches() || userInputString.length() > 80 || exists == false); // checks if string length is valid and if the string is within the list

      List<Publishers> publishersList = this.entityManager.createQuery("SELECT p FROM Publishers p WHERE p.email LIKE :email", Publishers.class).setParameter("email", userInputString).getResultList();
      System.out.printf("%-35s %-15s %-15s\n", "Name", "Phone Number", "Email");
      for(Publishers p:publishersList){
         System.out.printf("%-35s %-15s %-15s\n", p.getName(), p.getPhone(), p.getEmail());
      } // list data from publishersList
   } // end of search publisher email

   public void bookMenu() {
      System.out.println("\nWould you like to...");
      int userInputInt = validateInput("1. Add a Book\n2. Remove a Book\n3. Search for a Book\n4. Update Authoring Entity for Book\n5. Go Back\n> ", 5);
      if (userInputInt==1) {
         addBook();
      }//add book
      else if (userInputInt==2) {
         removeBook();
      } // remove book
      else if (userInputInt==3) {
         searchBookMenu();
      }// search for book
      else if (userInputInt==4) {
         updateBook();
      } // updates book
      else if (userInputInt==5) {
         return;
      } // returns to menu
   } // end of book menu

   public void addBook() {
      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = entityManager.getTransaction();
      System.out.println("Lets create a new Book.");
      Books newBook = new Books();
      newBook.setISBN(getNewBookISBN());
      newBook.setTitle(getNewBookTitle());
      newBook.setYear_published(getNewBookYearPublished());
      newBook.setPublisher_name(getNewBookPublisherName(newBook));
      newBook.setAuthoring_entity_name(getNewBookAuthoringEntity(newBook));
      //persist book
      LOGGER.fine("Beginning of Transaction");
      tx.begin();
      List<Books> newBooksList = new ArrayList<Books>();
      newBooksList.add(newBook);
      this.createEntity (newBooksList);
      tx.commit();
      LOGGER.fine("End of Transaction");

      System.out.println("Book successfully added.");
   } // end of add book function

   public String getNewBookISBN() {
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      //get ISBN for Books
      do {
         System.out.print("Enter ISBN for Book.\n> ");

         userInputString = sc.nextLine();

         if (userInputString.length() <= 1) System.out.println("That ISBN is too short, try again.");
         if (userInputString.length() > 17) System.out.println("That ISBN is too long, try again.");
      } while (userInputString.length() <= 1 || userInputString.length() > 17); // check if length of string is valid
      return userInputString;
   } // end of get new book with ISBN

   public String getNewBookTitle() {
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      do {
         System.out.print("Enter title for Book.\n> ");

         userInputString = sc.nextLine();

         if (userInputString.length() <= 1) System.out.println("That ISBN is too short, try again.");
         if (userInputString.length() > 80) System.out.println("That ISBN is too long, try again.");
      } while (userInputString.length() <= 1 || userInputString.length() > 80);
      return userInputString;
   } // end of get new book title function

   public int getNewBookYearPublished() {
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      String err; // used for error message
      do {
         System.out.print("Enter year published for Book.\n> ");
         err = "";

         userInputString = sc.nextLine();

         try
         {
            Integer.valueOf(userInputString);
            if (Integer.valueOf(userInputString) <= 1450) err = "That seems too long ago, try again.";
            if (Integer.valueOf(userInputString) > 2022) err = "Cannot be in the future, try again.";
         } // end of try
         catch(NumberFormatException e)
         {
            err = "Enter only numbers for year, please try again.";
         } //end of catch

         if(!err.equals("")) System.out.println(err); // display error message
      } while ( !err.equals("") ); // end when there is no error
      return Integer.valueOf(userInputString);
   } //end of get new book year published function

   public Publishers getNewBookPublisherName(Books newBook) {
      boolean publisherExists;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      //get publisher name for Books
      do {
         System.out.print("Enter publisher name for Book.\n> ");

         userInputString = sc.nextLine();

         publisherExists = this.findExiting("publishersNameExists", userInputString); //make sure publisher exists
         exists = (int) this.entityManager.createNamedQuery("titlePublisherExists").setParameter(1, "%"+userInputString+"%").setParameter(2,"%"+newBook.getTitle()+"%" ).getSingleResult() >= 1 ? true : false;

         if (exists) System.out.println("This publisher name is already associated with that title (" + newBook.getTitle() + "), enter a different publisher name.");
         if (!publisherExists) System.out.println("Please enter a publisher name that is already in our records. Try again.");
         if (userInputString.length() <= 1) System.out.println("That name is too short, try again.");
         if (userInputString.length() > 80) System.out.println("That name is too long, try again.");
      } while ( userInputString.length() <= 1 || userInputString.length() > 80 || exists || !publisherExists );
        // checks if input it valid and within character limit
      List<Publishers> publishersList = this.entityManager.createQuery("SELECT p FROM Publishers p WHERE UPPER(p.name) LIKE UPPER(:name)", Publishers.class).setParameter("name", "%"+userInputString+"%").getResultList();

      System.out.printf("%-2s%-35s %-15s %-15s\n", "", "Name", "Phone Number", "Email");
      int counter = 0;
      for(Publishers p:publishersList){
         counter++;
         System.out.printf("%d) %-35s %-15s %-15s\n", counter, p.getName(), p.getPhone(), p.getEmail());
      } // list info in publishers list

      userInputInt = validateInput("Please select a publisher below (1-" + counter + ")\n> ", counter);
      return publishersList.get( userInputInt - 1 );
   } // end of getNewBookPublisherName function

   public AuthoringEntities getNewBookAuthoringEntity(Books newBook) {
      Matcher matcher; // used to validate
      boolean exists = false; //used to check if value exists in DB
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      boolean authoringEntityExists; //used for books
      List<AuthoringEntities> AuthoringEntitiesList = new ArrayList<>(); //used for books
      //get authoring entity name for Books
      do {
         System.out.print("Enter authoring entity name for Book.\n> ");

         userInputString = sc.nextLine();

         authoringEntityExists = this.findExiting("AuthoringNameExists", userInputString); //make sure authoring entity exists

         if(authoringEntityExists) {

            //list all with similar name
            AuthoringEntitiesList = this.entityManager.createQuery("SELECT a FROM AuthoringEntities a WHERE UPPER(a.name) LIKE UPPER(:name)", AuthoringEntities.class).setParameter("name", "%" + userInputString + "%").getResultList();

            System.out.printf("%-2s %-35s %-15s\n", "", "Name", "Email");
            int counter = 0;
            for (AuthoringEntities a : AuthoringEntitiesList) {
               counter++;
               System.out.printf("%d) %-35s %-15s\n", counter, a.getName(), a.getEmail());
            } // list info from authoring entities list

            //make sure user selects only 1
            userInputInt = validateInput("Please select an authoring entity below (1-" + counter + ")\n>", counter);

            exists = (int) this.entityManager.createNamedQuery("titleAuthoringExists").setParameter(1, "%"+AuthoringEntitiesList.get(userInputInt - 1).getName()+"%").setParameter(2,"%"+newBook.getTitle()+"%" ).getSingleResult() >= 1 ? true : false;
         } // find the entity name given


         if (exists) System.out.println("This authoring entity is already associated with that title (" + newBook.getTitle() + "), enter a different authoring entity.");
         if (!authoringEntityExists) System.out.println("Please enter an authoring entity that is already in our records. Try again.");
      } while (exists || !authoringEntityExists );// ends authoring entity exist
      return AuthoringEntitiesList.get(userInputInt - 1);
   } // end of getNewBookAuthoringEntity function

   public void removeBook() {
      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = entityManager.getTransaction();
      boolean exists; //used to check if value exists in DB
      Matcher matcher; // used to validate
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      do {
         System.out.print("Enter title for Book you wish to delete.\n> ");
         userInputString = sc.nextLine();
         exists = this.findExiting("booksTitleExists", userInputString);
         if(!exists) System.out.println("Hm that doesnt seem to exists in our records, try again.");
      }while( !exists );
      List<Books> booksList = this.entityManager.createQuery("SELECT b FROM Books b WHERE UPPER(b.title) LIKE UPPER(:title)", Books.class).setParameter("title", "%"+userInputString+"%").getResultList();
      System.out.printf("%-2s %-35s %-15s %-15s\n", "", "ISBN", "Title", "Year");
      int counter = 0;
      for(Books b:booksList){
         counter++;
         System.out.printf("%d) %-35s %-15s %-15s\n", counter, b.getISBN(), b.getTitle(), b.getYear_published());
      } // display info from  books list
      userInputInt = validateInput("Please select a book below (1-" + counter + ")\n> ", counter);
      //delete selected publisher
      System.out.println("Now deleting " + booksList.get(userInputInt-1).getTitle());
      LOGGER.fine("Beginning of Transaction");
      tx.begin();
      this.entityManager.remove(booksList.get(userInputInt-1));
      tx.commit();
      LOGGER.fine("End of Transaction");
   } // end of remove book function

   public void searchBookMenu() {
      int userInputInt = validateInput("1. Search using ISBN\n2. Search using title\n3. Search using year published\n4. Go Back\n> ", 4);
      if (userInputInt==1) {
         searchBookISBN();
      } // search ISBN
      else if (userInputInt==2) {
         searchBookTitle();
      }// search title
      else if (userInputInt==3) {
         searchBookYearPublished();
      } // search year published
      else if (userInputInt==4) {
         return;
      } // checks if user want to return to menu
   } // end of search book menu

   public void searchBookISBN() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      do {
         System.out.print("Enter ISBN for a Book OR enter 'exit' to go back to menu\n> ");
         Pattern pattern = Pattern.compile("[0-9_@.#-]*$");
         userInputString = sc.nextLine();
         if (userInputString.toUpperCase().equals("EXIT")) {
            return;
         } // checks if user want to return to menu
         matcher = pattern.matcher(userInputString);

         if (userInputString.length() <= 1) System.out.println("That name is too long or short, try again.");
         else if (!matcher.matches()) System.out.println("Not a valid ISBN, please try again");
      } while (!matcher.matches() || userInputString.length() > 17); // checks if the input matches and is below character limit
      List<Books> booksList = this.entityManager.createQuery("SELECT b FROM Books b WHERE b.ISBN LIKE :ISBN", Books.class).setParameter("ISBN", userInputString).getResultList();
      if (booksList.isEmpty()) {
         System.out.println("This ISBN is not associated with any Books");
         return;
      } // checks if the books list is empty
      System.out.printf("%-20s %-45s %-15s %-30s %-30s\n", "ISBN", "Title", "Year Published", "Publisher", "Authoring Entity");
      for(Books b:booksList){
         System.out.printf("%-20s %-45s %-15s %-30s %-30s\n", b.getISBN(), b.getTitle(), b.getYear_published(), b.getPublisher_name().getName(), b.getAuthoring_entity_name().getName());
      } // display info from from book list
   }// end of search book ISBN function

   public void searchBookTitle() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      System.out.println("Enter the title of the Book OR enter '0' to go back to menu\n>");

      userInputString = sc.next();
      if (userInputString.equals("0")) {
         this.menu();
         return;
      } // return user to menu
      List<Books> booksList = this.entityManager.createQuery("SELECT b FROM Books b WHERE UPPER(b.title) LIKE UPPER(:title)", Books.class).setParameter("title", "%"+userInputString+"%").getResultList();
      System.out.printf("%-20s %-45s %-15s %-30s %-30s\n", "ISBN", "Title", "Year Published", "Publisher", "Authoring Entity");
      for(Books b:booksList){
         System.out.printf("%-20s %-45s %-15s %-30s %-30s\n", b.getISBN(), b.getTitle(), b.getYear_published(), b.getPublisher_name().getName(), b.getAuthoring_entity_name().getName());
      } // display info from from books list
   } // end of search book title

   public void searchBookYearPublished() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE; // default value is to return to menu
      Matcher matcher; // used to validate
      do {
         System.out.print("Enter year for a Book.(ex. 1234) OR enter 'exit' to go back to menu\n> ");
         Pattern pattern = Pattern.compile("^\\d{4}$");

         userInputString = sc.nextLine();
         matcher = pattern.matcher(userInputString);
         if (userInputString.toUpperCase().equals("EXIT")) {
            this.menu();
            return;
         } // checks if user want to exit back to menu

         else if (!matcher.matches()) System.out.println("That is not a valid year, please try again.");
      } while (!matcher.matches() || userInputString.length() > 80); // checks if string matches and is below character limit
      List<Books> booksList = this.entityManager.createQuery("SELECT b FROM Books b WHERE b.year_published = :year_published", Books.class).setParameter("year_published", Integer.valueOf(userInputString)).getResultList();


      if (booksList.isEmpty()) {
         System.out.println("There are no books published of this year");
         this.menu();
         return;
      } // checks if the books list is empty
      System.out.printf("%-20s %-45s %-15s %-30s %-30s\n", "ISBN", "Title", "Year Published", "Publisher", "Authoring Entity");
      for(Books b:booksList){
         System.out.printf("%-20s %-45s %-15s %-30s %-30s\n", b.getISBN(), b.getTitle(), b.getYear_published(), b.getPublisher_name().getName(), b.getAuthoring_entity_name().getName());
      } // displays infrom from bookslist
   } // end of searchBookYearPublished

   public void updateBook() {
      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = entityManager.getTransaction();
      Books bookSelected = selectBook();
      AuthoringEntities newAuthoringEntity = updateAuthoring(bookSelected);
      LOGGER.fine("Beginning of Transaction");
      tx.begin();
      bookSelected.setAuthoring_entity_name(newAuthoringEntity);
      tx.commit();
      LOGGER.fine("End of Transaction");
      System.out.println(bookSelected.getTitle() + " now has the Authoring Entity: " + newAuthoringEntity.getName());

   } // end of update book

   public Books selectBook() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do
      {
         System.out.print("Enter the the name of a book you want to update.\n> ");

         userInputString = sc.nextLine();

         exists = findExiting("booksTitleExists", userInputString);

         if(userInputString.length() < 1 || userInputString.length() > 80) System.out.println("Character length must be between 1 and 80. Try again.");
         else if( !exists ) System.out.println("There does not seem to be a book with that name in our records, please try again.");
      } while( !exists || userInputString.length() < 1 || userInputString.length() > 80); // check if string exist in list and within character limit.

      List<Books> booksList =  this.entityManager.createQuery("SELECT a FROM Books a WHERE UPPER(a.title) LIKE UPPER(:title)", Books.class).setParameter("title", "%"+userInputString+"%").getResultList();

      System.out.printf("%-2s %-20s %-30s %-20s %-30s %-30s\n", "", "ISBN", "Title", "Year Published", "Publisher Name", "Authoring Entity Name");
      int counter = 0;
      for(Books b:booksList){
         counter++;
         System.out.printf("%d) %-20s %-30s %-20s %-30s %-30s\n", counter, b.getISBN(), b.getTitle(), b.getYear_published(), b.getPublisher_name().getName(), b.getAuthoring_entity_name().getName());
      } // display info from books list

      userInputInt = validateInput("Please select a book below (1-" + counter + ")\n> ", counter);

      return booksList.get(userInputInt-1);
   } // end of select book

   public AuthoringEntities updateAuthoring(Books bookSelected) {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      System.out.println(bookSelected.getTitle() + " has the Authoring Entity: " + bookSelected.getAuthoring_entity_name().getName());
      //select a new authoring entity, cant be the same
      do
      {
         System.out.print("Enter the the name of the new Authoring Entity for " + bookSelected.getTitle() + ". \n> ");

         userInputString = sc.nextLine();

         exists = findExiting("AuthoringNameExists", userInputString);

         if(userInputString.length() < 1 || userInputString.length() > 80) System.out.println("Character length must be between 1 and 80. Try again.");
         else if( !exists ) System.out.println("There does not seem to be an Authoring Entity with that name in our records, please try again.");
      } while( !exists || userInputString.length() < 1 || userInputString.length() > 80);

      List<AuthoringEntities> AuthEntList =  this.entityManager.createQuery("SELECT a FROM AuthoringEntities a WHERE UPPER(a.name) LIKE UPPER(:name)", AuthoringEntities.class).setParameter("name", "%"+userInputString+"%").getResultList();

      if(AuthEntList.size() == 1 && AuthEntList.get(0).getEmail() == bookSelected.getAuthoring_entity_name().getEmail())
      {
         System.out.println("Sorry you cannot set the same Authoring Entity, return to main menu.");
         return null;
      }

      System.out.printf("%-2s %-20s %-30s %-20s \n", "", "Name", "Email", "Type");
      int counter = 0;
      for(AuthoringEntities b:AuthEntList){
         counter++;
         System.out.printf("%d) %-20s %-30s %-20s \n", counter, b.getName(), b.getEmail(), b.getClass().getName().substring(20) );
      }

      userInputInt = validateInput("Please select an Authoring Entity below (1-" + counter + ")\n> ", counter);

      return AuthEntList.get(userInputInt-1);
   }

   public String getNewWGEmail() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do {
         System.out.print("Enter email for Writing Group .(ex. test@example.com)\n> ");
         Pattern pattern = Pattern.compile("^(.+)@(.+)$"); // ^(.+)@(.+)$

         userInputString = sc.nextLine();
         matcher = pattern.matcher(userInputString);
         exists = this.findExiting("AuthoringEmailExists", userInputString);

         if (!matcher.matches()) System.out.println("That is not a valid email, please try again.");
         if (exists) System.out.println("That email already exists, please enter a new one.");
      } while (!matcher.matches() || userInputString.length() > 30 || exists == true); // checks if input exist already and is within character limits.
      return userInputString.toLowerCase();
   }

   public String getNewWGName() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do {
         System.out.print("Enter name for Writing Group.\n> ");

         userInputString = sc.nextLine();

         if(userInputString.length() > 80 || userInputString.length() < 1) System.out.println("That length of characters does not work, try again.");
      } while (userInputString.length() > 80 ); // checks string if its under character limit.
      return userInputString;
   } // end of get new WGNAme

   public String getNewWGHeadWriter() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do {
         System.out.print("Enter head writer name for Writing Group.\n> ");

         userInputString = sc.nextLine();

         if(userInputString.length() > 80 || userInputString.length() < 1) System.out.println("That length of characters does not work, try again.");
      } while (userInputString.length() > 80 ); // checks user input if its under character limit.
      return userInputString;
   } // end of getNewWGHeadWriter

   public int getNewWGYearFormed() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      String err = ""; //used for year
      //get year formed
      do {
         System.out.print("Enter the year the writing group was formed.\n> ");
         err = "";

         userInputString = sc.nextLine();

         try
         {
            Integer.valueOf(userInputString);
            if (Integer.valueOf(userInputString) <= 1450) err = "That seems too long ago, try again.";
            if (Integer.valueOf(userInputString) > 2022) err = "Cannot be in the future, try again.";
         } // end of try
         catch(NumberFormatException e)
         {
            err = "Enter only numbers for year, please try again.";
         } // end of catch

         if(!err.equals("")) System.out.println(err);
      } while ( !err.equals("") );// check if there are no error
      return Integer.valueOf(userInputString);
   } // end of getNewWGYearFormed

   public String getNewIAEmail() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do {
         System.out.print("Enter email for Individual Author .(ex. test@example.com)\n> ");
         Pattern pattern = Pattern.compile("^(.+)@(.+)$");

         userInputString = sc.nextLine();
         matcher = pattern.matcher(userInputString);
         exists = this.findExiting("AuthoringEmailExists", userInputString);

         if (!matcher.matches()) System.out.println("That is not a valid email, please try again.");
         if (exists) System.out.println("That email already exists, please enter a new one.");
      } while (!matcher.matches() || userInputString.length() > 30 || exists == true); // checks if string exist and is within character limits.

      return userInputString.toLowerCase();
   } // end of get new IA Email

   public String getNewIAName() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do {
         System.out.print("Enter name for Individual Author.\n> ");

         userInputString = sc.nextLine();

         if(userInputString.length() > 80 || userInputString.length() < 1) System.out.println("That length of characters does not work, try again.");
      } while (userInputString.length() > 80 ); // checks if string length is below limit
      return userInputString;
   } // end of get New IA Name

   public String getNewAHTEmail() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE; // defaults value to return to menu
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do {
         System.out.print("Enter email for Individual Author .(ex. test@example.com)\n> ");
         Pattern pattern = Pattern.compile("^(.+)@(.+)$");

         userInputString = sc.nextLine();
         matcher = pattern.matcher(userInputString);
         exists = this.findExiting("AuthoringEmailExists", userInputString);

         if (!matcher.matches()) System.out.println("That is not a valid email, please try again.");
         if (exists) System.out.println("That email already exists, please enter a new one.");
      } while (!matcher.matches() || userInputString.length() > 30 || exists == true); // checks if string exist and is below character limit.
      return userInputString.toLowerCase();
   } // end of getNew AHT Email

   public String getNewAHTName() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do {
         System.out.print("Enter name for Individual Author.\n> ");

         userInputString = sc.nextLine();

         if(userInputString.length() > 80 || userInputString.length() < 1) System.out.println("That length of characters does not work, try again.");
      } while (userInputString.length() > 80 ); // check if string is under character limit
      return userInputString;
   } // end of get new AHT Name

   public void addAuthoringEntityMenu() {
      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = entityManager.getTransaction();
      LOGGER.fine("Beginning of Transaction");
      tx.begin();
      AuthoringEntities newAutoringEntity = new AuthoringEntities();
      int userInputInt = validateInput("1. Add a Writing Group\n2. Add an Individual Author\n3. Add an Ad Hoc Team\n4. Go back> ", 4);
      if (userInputInt==1) {
         newAutoringEntity = new WritingGroups();
         newAutoringEntity.setEmail(getNewWGEmail());
         newAutoringEntity.setName(getNewWGName());
         newAutoringEntity.setHead_writer(getNewWGHeadWriter());
         newAutoringEntity.setYear_formed(getNewWGYearFormed());
      }//Add writing group
      else if (userInputInt==2) {
         newAutoringEntity = new IndividualAuthors();
         newAutoringEntity.setEmail(getNewIAEmail());
         newAutoringEntity.setName(getNewIAName());
      }// add individual
      else if (userInputInt==3) {
         newAutoringEntity = new AdHocTeams();
         newAutoringEntity.setEmail(getNewAHTEmail());
         newAutoringEntity.setName(getNewAHTName());
      }  // add ad hoc
      else if (userInputInt==4) {
         return;
      } // return to menu

      List<AuthoringEntities> newAuthoringList = new ArrayList<AuthoringEntities>();
      newAuthoringList.add(newAutoringEntity);
      this.createEntity(newAuthoringList);
      tx.commit();
      LOGGER.fine("End of Transaction");

   } // end of addAuthoringEntityMenu

   public void searchAuthoringEntity() {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      int counter = 0; // used later
      List<AuthoringEntities> AuthoringEntitiesList = new ArrayList<>();// used to find ad hoc team

      do
      {
         System.out.print("Enter the name of an Authoring Entity (of any type).\n> ");

         userInputString = sc.nextLine();

         exists = this.findExiting("AuthoringNameExists", userInputString); //make sure authoring entity exists

         if( !exists ) System.out.println("Hm, that name does not appear in our records, please try again.");
      }while( !exists ); // check if the string exist in  AuthoringEntitiesList

      //list all with similar name
      AuthoringEntitiesList = this.entityManager.createQuery("SELECT a FROM AuthoringEntities a WHERE UPPER(a.name) LIKE UPPER(:name) ", AuthoringEntities.class).setParameter("name", "%" + userInputString + "%").getResultList();

      System.out.printf("%-2s %-35s %-30s %-15s\n", "", "Name", "Email", "Type");
      for (AuthoringEntities a : AuthoringEntitiesList) {
         counter++;
         System.out.printf("%d) %-35s %-30s %-15s\n", counter, a.getName(), a.getEmail(), a.getClass().getName().substring(20) );
      } // display info from authoring entities list
   } // end of search Authoring Entity

   public AdHocTeams getAH(List<AuthoringEntities> AuthoringEntitiesList) {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      int counter = 0;
      do
      {
         System.out.print("Lets find the Ad Hoc Team you want to add an Individual Author to. Enter the name.\n> ");

         userInputString = sc.nextLine();

         exists = this.findExiting("AdHockExists", userInputString); //make sure authoring entity exists

         if( !exists ) System.out.println("Hm, that name does not appear in our records, please try again.");
      }while( !exists ); // check if the string exist

      //list all with similar name
      AuthoringEntitiesList = this.entityManager.createQuery("SELECT a FROM AuthoringEntities a WHERE UPPER(a.name) LIKE UPPER(:name) AND TYPE(a) = AdHocTeams ", AuthoringEntities.class).setParameter("name", "%" + userInputString + "%").getResultList();

      System.out.printf("%-2s %-35s %-15s\n", "", "Name", "Email");
      for (AuthoringEntities a : AuthoringEntitiesList) {
         counter++;
         System.out.printf("%d) %-35s %-15s\n", counter, a.getName(), a.getEmail());

      } // display info from AuthoringEntitiesList

      userInputInt = validateInput("Please select the Ad Hoc Team below below (1-" + counter + ")\n> ", counter);
      return (AdHocTeams) AuthoringEntitiesList.get(userInputInt-1);
   } // end of getAH

   public IndividualAuthors getIA(List<AuthoringEntities> AuthoringEntitiesList, AdHocTeams AdHocSelected) {
      Scanner sc = new Scanner(System.in);
      String userInputString = ""; //used later
      int userInputInt = Integer.MAX_VALUE;
      Matcher matcher; // used to validate
      boolean exists; //used to check if value exists in DB
      do
      {
         userInputString = sc.nextLine();
         exists = this.findExiting("IndividualAuthNameExists", userInputString); //make sure indiv author exists
         if( !exists ) System.out.print("Hm, that name does not appear in our records, please try again.\n> ");
      }while( !exists );

      //list all with similar name
      AuthoringEntitiesList = this.entityManager.createQuery("SELECT a FROM AuthoringEntities a WHERE UPPER(a.name) LIKE UPPER(:name) AND TYPE(a) = IndividualAuthors ", AuthoringEntities.class).setParameter("name", "%" + userInputString + "%").getResultList();

      System.out.printf("%-2s %-35s %-15s\n", "", "Name", "Email");
      int counter = 0;
      for (AuthoringEntities a : AuthoringEntitiesList) {
         counter++;
         System.out.printf("%d) %-35s %-15s\n", counter, a.getName(), a.getEmail());
      }
      userInputInt = validateInput("Please select a Individual Author below (1-" + counter + ")\n> ", counter);
      IndividualAuthors IndividualAuthorSelected = (IndividualAuthors) AuthoringEntitiesList.get(userInputInt-1);
      //check if AdHocTeam already has that indiv author
      exists = (int) this.entityManager.createNamedQuery("AdHocHasAuthor").setParameter(1, AdHocSelected.getEmail()).setParameter(2, IndividualAuthorSelected.getEmail()).getSingleResult() >= 1 ? true : false;
      if(exists)  {
         System.out.println("Oops, looks like " + IndividualAuthorSelected.getName() + " is already assocaited with " + AdHocSelected.getName());
         return null;
      }
      return IndividualAuthorSelected;
   }

   public void addIAtoAHTMenu() {
      LOGGER.fine("Begin of Transaction");
      EntityTransaction tx = entityManager.getTransaction();
      List<AuthoringEntities> AuthoringEntitiesList = new ArrayList<>();// used to find ad hoc team
      AdHocTeams AdHocSelected = getAH(AuthoringEntitiesList);
      System.out.print(AdHocSelected.getName() + " was selected! Now enter the name of the Individual Author\n> ");
      IndividualAuthors IndividualAuthorSelected = getIA(AuthoringEntitiesList, AdHocSelected);
      if (IndividualAuthorSelected == null) {
         return;
      } // check if value is null
      LOGGER.fine("Beginning of Transaction");
      tx.begin();
      AdHocSelected.addIndividualAuthors(IndividualAuthorSelected);
      tx.commit();
      LOGGER.fine("End of Transaction");
      System.out.println(IndividualAuthorSelected.getName() + " successfully added to " + AdHocSelected.getName());

   } // end of addIAtoAHTMenu

   public void authoringEntityMenu() {
      System.out.println("\nWould you like to...");
      int userInputInt = validateInput("1. Add an Authoring Entity\n2. Find an Authoring Entity\n3. Add Individual Author to Ad Hoc Team\n4. Go Back\n> ", 4); //removed and commented out remove
      if (userInputInt==1) {
         addAuthoringEntityMenu();
      }//add AE
      else if (userInputInt==2) {
         searchAuthoringEntity();
      } //find
      else if (userInputInt==3) {
         addIAtoAHTMenu();
      } //add invididual author to ad hoc
      else if (userInputInt==4) {
         return;
      } // checks if user want to return to menu

   } // end of authoring entity menu

   public void menu() {
      //Display menu options
      Scanner sc = new Scanner(System.in);
      int userInputInt = Integer.MAX_VALUE; // default to return to menu
      String userInputString = ""; //used later
      boolean validIn;  // used to check if action is valid
      System.out.println("\nYour options are listed below. Selecting one will provide more options");
      userInputInt = validateInput("1. Publishers\n2. Books\n3. Authoring Entities\n4. Primary Keys\n5. Exit\n> ", 5);
      //display Publisher options
      if (userInputInt == 1) {
         publisherMenu();
         this.menu();
      } // goes to publisher menu

      else if (userInputInt == 2) { // books
         bookMenu();
         this.menu();
      }
 // goes to book benu
      //display Authoring Entities options
      else if (userInputInt == 3)
      {
         authoringEntityMenu();
         this.menu();
      } // authoring entity menu

      else if (userInputInt==4) {
         primaryKeyMenu();
         this.menu();
      } // goes to primary key menu
      else if (userInputInt==5) {
         return;
      } // return to menu
      return;
   } // end of the menu

   public void primaryKeyMenu() {
      int userInputInt = validateInput("1. Publishers\n2. Books\n3. Authoring Entities\n4. Go back\n>", 4);
      if (userInputInt==1) {
         publisherPrimaryKey();
      }//displays publisher primary key
      else if (userInputInt==2) {
         booksPrimaryKey();
      }// display books primary key
      else if (userInputInt==3) {
         authoringEntityPrimaryKey();
      }  // Display Authoring entity primary key
      else if (userInputInt==4) {
         return;
      } // return back to menu
   }// end of primary key menu

   public void publisherPrimaryKey() {
      List <Publishers> publishersList = this.entityManager.createQuery("SELECT p FROM Publishers p", Publishers.class).getResultList();
      if (publishersList.isEmpty()) {
         System.out.println("No publishers here\n");
      } // checks if there are no publishers in list.
      else {
         System.out.printf("\n%-35s\n", "Publisher Names");
         int count = 1;
         for(Publishers p:publishersList){
            System.out.printf("%d) %-32s\n", count, p.getName());
            count++;
         } // display the publisher's name
      } // checks if there are no publisher in the list
      System.out.println("Returning you to main menu!");
   } // end of publisher primary key

   public void booksPrimaryKey() {
      List<Books> booksList = this.entityManager.createQuery("SELECT b FROM Books b", Books.class).getResultList();
      if (booksList.isEmpty()) {
         System.out.println("No books here\n");
      } // checks if there are no books in the books list
      else {
         System.out.printf("\n%-35s %-15s\n", "ISBN", "Title");
         int count = 1;
         for(Books b: booksList) {
            System.out.printf("%d) %-32s %-15s\n", count, b.getISBN(), b.getTitle());
            count++;
         } //loops and displays the ISBN and title
      } // displays the ISBN and tital of each book
      System.out.println("Returning you to main menu!");
   } // end of booksPrimaryKey

   public void authoringEntityPrimaryKey() {
      List<AuthoringEntities> authoringEntitiesList = this.entityManager.createQuery("SELECT a FROM AuthoringEntities a", AuthoringEntities.class).getResultList();
      if (authoringEntitiesList.isEmpty()) {
         System.out.println("No Authoring Entities here\n");
      } // checks if there are no authoring entity
      else {
         System.out.printf("\n%-35s %-15s\n", "Email", "Type");
         int count = 1;
         for(AuthoringEntities a: authoringEntitiesList) {
            System.out.printf("%d) %-32s %-15s\n", count, a.getEmail(), a.getClass().getSimpleName());
            count++;
         } // display the email , class and name of Authoring Entities.
      } // checks if there are elements in the authoringEntitiesList
      System.out.println("Returning you to main menu!");
   } // end of authoringEntityPrimaryKey
}//end of main

