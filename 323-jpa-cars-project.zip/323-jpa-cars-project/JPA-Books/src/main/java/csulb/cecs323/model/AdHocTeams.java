/**
 AdHocTeams class for Authoring Entity
 Homework Assignment: JPA - Books
 @author Frank Mancia, Jett Sonoda, Eric Nguyen
 @version 1.01 03/25/2022
 */
package csulb.cecs323.model;

import javax.persistence.*;
import java.util.ArrayList;

@Entity
@DiscriminatorColumn ( name = "AHT" )
//Query to check if ad hoc team is already associated with individual author using email
@NamedNativeQuery(
        name="AdHocHasAuthor",
        query = "SELECT COUNT(individual_authors_email) " +
                "FROM ad_hoc_teams_member " +
                "WHERE ad_hoc_teams_email LIKE ? "
)
/**
 * A group of people that forms when necessary
 */
public class AdHocTeams extends AuthoringEntities
{
    /** Constructor for AdHocTeams, extends to AuthoringEntities **/
    public AdHocTeams(String name, String email)
    {
        super(name, email);
    }

    /** Default construcor for AdHocTeams **/
    public AdHocTeams() {}

    /** JPA ManyToMany to create junction table between AdHocTeams and IndividualAuthors **/
    @ManyToMany
    @JoinTable(
            name = "ad_hoc_teams_member",
            joinColumns = @JoinColumn(name = "ad_hoc_teams_email", referencedColumnName = "email"),
            inverseJoinColumns = @JoinColumn(name = "individual_authors_email", referencedColumnName = "email")
    )
    ArrayList<IndividualAuthors> individualAuthors = new ArrayList<IndividualAuthors>();

    /** add individual authors to junction table 'ad_hoc_teams_member' to be associated with a AdHocTeam **/
    public void addIndividualAuthors (IndividualAuthors author)
    {
        this.individualAuthors.add(author);
    }

}
