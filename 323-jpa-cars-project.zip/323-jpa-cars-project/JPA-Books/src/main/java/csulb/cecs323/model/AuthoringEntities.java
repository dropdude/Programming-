/**
 Authoring Entities class used to describe authors to Books
 Homework Assignment: JPA - Books
 @author Frank Mancia, Jett Sonoda, Eric Nguyen
 @version 1.01 03/25/2022
 */
package csulb.cecs323.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
//Allows to use the category present in the UML
@Inheritance( strategy = InheritanceType.SINGLE_TABLE )
//allows us to capture the type of entity it is (AdHocTeam, WritingGroup, IndividualAuthors)
@DiscriminatorColumn(name = "authoring_entity_type ", discriminatorType = DiscriminatorType.STRING, length = 31)
//Query to find if a certain name exists for all authoring entities
@NamedNativeQuery(
        name="AuthoringNameExists",
        query = "SELECT COUNT(name) " +
                "FROM AuthoringEntities " +
                "WHERE UPPER(name) LIKE UPPER(?) "
)
//Query to find if a certain email exists for all authoring entities
@NamedNativeQuery(
        name="AuthoringEmailExists",
        query = "SELECT COUNT(email) " +
                "FROM AuthoringEntities " +
                "WHERE UPPER(email) LIKE UPPER(?) "
)
//Query to find an IndividualAuthor with a name already exists
@NamedNativeQuery(
        name="IndividualAuthNameExists",
        query = "SELECT COUNT(a.name) " +
                "FROM AuthoringEntities as a " +
                "WHERE UPPER(a.name) LIKE UPPER(?)  AND authoring_entity_type = 'IndividualAuthors'"
)
//Query to find an AdHocTeam with a name already exists
@NamedNativeQuery(
        name="AdHockExists",
        query = "SELECT COUNT(name) " +
                "FROM AuthoringEntities " +
                "WHERE UPPER(name) LIKE UPPER(?) AND authoring_entity_type = 'AdHocTeams'"
)
/**
 * A generic person or group of people that write books
 */
public class AuthoringEntities implements Serializable
{
    /** The email of the Authoring Entity. */
    @Id
    @Column(length = 30, nullable = false)
    private String email;

    /** The name of the Authoring Entity. */
    @Column(length = 80, nullable = false)
    private String name;

    /** The name of the head writer in a Writing Group, if that exists. */
    @Column(length = 80)
    private String head_writer;

    /** The year the Writing Group was formed, if that exists. */
    @Column
    private int year_formed;

    /** Constructor used for Individual Author and AdHocTeams **/
    public AuthoringEntities(String name, String email)
    {
        this.name = name;
        this.email = email;
    }

    /** Constructor used for WritingGroups **/
    public AuthoringEntities(String name, String email, String head_writer, int year_formed)
    {
        this.name = name;
        this.email = email;
        this.head_writer = head_writer;
        this.year_formed = year_formed;
    }

    /** Default constructor **/
    public AuthoringEntities() { }

    /** retrieve the email of Authoring Entity **/
    public String getEmail() { return email; }

    /** set the email for Authoring Entity **/
    public void setEmail(String email) { this.email = email; }

    /** retrieve the name of Authoring Entity **/
    public String getName() { return name; }

    /** set the name for Authoring Entity **/
    public void setName(String name) { this.name = name; }

    /** retrieve the name of the head writer of a Writing Group **/
    public String getHead_writer() { return head_writer; }

    /** set the head writer name for the Writing Group **/
    public void setHead_writer(String head_writer) { this.head_writer = head_writer; }

    /** retrieve the year the Writing Group was formed **/
    public int getYear_formed() { return year_formed; }

    /** set the year the Writing Group was formed **/
    public void setYear_formed(int year_formed) {  this.year_formed = year_formed; }

    /** toString function used for Individual Authors and AdHocTeams **/
    @Override
    public String toString()
    {
        return "Type of Authoring Entity: " + this.getClass().getName().substring(20) + " Name: " + this.name + " Email: " + this.email;
    }
}
