/**
 Books class to record list of Books alone with Publishers and Authors
 Homework Assignment: JPA - Books
 @author Frank Mancia, Jett Sonoda, Eric Nguyen
 @version 1.01 03/25/2022
 */
package csulb.cecs323.model;

import javax.persistence.*;

@Entity
//allows for candidate key between {title, publisher} and {title, authoring entity}
@Table(uniqueConstraints =
{
    @UniqueConstraint(columnNames = {"title", "publisher_name"}),
    @UniqueConstraint(columnNames = {"title", "authoring_entity_name"}) //not sure if we need to assign name to unique restraints
})
//Query to find a title already exists with a publisher
@NamedNativeQuery(
        name="titlePublisherExists",
        query = "SELECT COUNT(title) " +
                "FROM Books " +
                "WHERE UPPER(publisher_name) LIKE UPPER(?) AND UPPER(title) LIKE UPPER(?)"
)
//Query to find a title already exists with an authoring entity
@NamedNativeQuery(
        name="titleAuthoringExists",
        query = "SELECT COUNT(title) " +
                "FROM Books " +
                "WHERE UPPER(authoring_entity_name) LIKE UPPER(?) AND UPPER(title) LIKE UPPER(?) "
)
//Query to find if that title exists in records
@NamedNativeQuery(
        name="booksTitleExists",
        query = "SELECT COUNT(title) " +
                "FROM Books " +
                "WHERE UPPER(title) LIKE UPPER(?)  "
)
/** A collection of pages bounded by a cover, written by an author. */
public class Books
{
    /** The ISBN of the Book. */
    @Id
    @Column(nullable = false, length = 17)
    private String ISBN;

    /** The title of the Book. */
    @Column(nullable = false, length = 80)
    private String title;

    /** The year the Book was published. */
    @Column(nullable = false)
    private int year_published;

    /** Brings in the publisher entity to the Book **/
    @ManyToOne
    @JoinColumn(name = "publisher_name", referencedColumnName = "name", nullable = false)
    private Publishers publisher_name;

    /** Brings in the Authoring Entity to the Book **/
    @ManyToOne
    @JoinColumn(name = "authoring_entity_name", referencedColumnName = "name", nullable = false)
    private AuthoringEntities authoring_entity_name;

    /** Constructor to create a Book **/
    public Books(String ISBN, String title, int year_published, Publishers publisher_name, AuthoringEntities authoring_entity_name)
    {
        this.ISBN = ISBN;
        this.title = title;
        this.year_published = year_published;
        this.publisher_name = publisher_name;
        this.authoring_entity_name = authoring_entity_name;
    }

    /** Default constructor for Book **/
    public Books() {}

    /** retrieve the ISBN for Book **/
    public String getISBN() { return ISBN; }

    /** set the ISBN for a Book **/
    public void setISBN(String ISBN) { this.ISBN = ISBN; }

    /** retrieve the title for a Book **/
    public String getTitle() { return title; }

    /** set the title for Book **/
    public void setTitle(String title) { this.title = title; }

    /** retrieve the year Book was published **/
    public int getYear_published() { return year_published; }

    /** set the year Book was published **/
    public void setYear_published(int year_published) { this.year_published = year_published; }

    /** retrieve the Publisher Entity with Book **/
    public Publishers getPublisher_name() { return this.publisher_name; }

    /** set the Publisher Entity for Book **/
    public void setPublisher_name (Publishers publisher_name) { this.publisher_name = publisher_name; }

    /** retrieve the Authoring Entity for Book **/
    public AuthoringEntities getAuthoring_entity_name() { return this.authoring_entity_name; }

    /** set the Authoring Entity for Book **/
    public void setAuthoring_entity_name(AuthoringEntities authoring_entity_name) { this.authoring_entity_name = authoring_entity_name; }

    /** toString function for Books listing all attributes **/
    @Override
    public String toString()
    {
        return "ISBN: " + this.ISBN + ", Title: " + this.title + ", Year Published: " + this.year_published;
    }
}
