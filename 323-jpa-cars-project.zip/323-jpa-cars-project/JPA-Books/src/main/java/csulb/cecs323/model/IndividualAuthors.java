/**
 Individual Authors class for Authoring Entity
 Homework Assignment: JPA - Books
 @author Frank Mancia, Jett Sonoda, Eric Nguyen
 @version 1.01 03/25/2022
 */
package csulb.cecs323.model;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;

@Entity
@DiscriminatorColumn ( name = "IA" )
public class IndividualAuthors extends AuthoringEntities
{
    /** Constructor for IndividualAuthors, extends to AuthoringEntities **/
    public IndividualAuthors(String name, String email)
    {
        super(name, email);
    }

    /** Default constructor for IndividualAuthors **/
    public IndividualAuthors() {}

}
