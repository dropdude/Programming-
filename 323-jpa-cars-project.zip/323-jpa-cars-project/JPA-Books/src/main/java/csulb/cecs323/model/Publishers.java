/**
 Publisher class records list of Publishers for Books
 Homework Assignment: JPA - Books
 @author Frank Mancia, Jett Sonoda, Eric Nguyen
 @version 1.01 03/25/2022
 */
package csulb.cecs323.model;

import javax.persistence.*;

@Entity
//Query to check if phone exists in publishers records
@NamedNativeQuery(
        name="publishersPhoneExists",
        query = "SELECT COUNT(phone) " +
        "FROM PUBLISHERS " +
        "WHERE phone LIKE ? "
)
//Query to check if email exists in publishers records
@NamedNativeQuery(
        name="publishersEmailExists",
        query = "SELECT COUNT(email) " +
                "FROM PUBLISHERS " +
                "WHERE email LIKE ? "
)
//Query to check if name exists in publishers records
@NamedNativeQuery(
        name="publishersNameExists",
        query = "SELECT COUNT(name) " +
                "FROM PUBLISHERS " +
                "WHERE UPPER(name) LIKE UPPER(?) "
)
/** A person or company that prepares and issues books. */
public class Publishers
{
    /** The name for Publisher **/
    @Id
    @Column(nullable = false, length = 80)
    private String name;

    /** The phone number of Publisher **/
    @Column(nullable = false, length = 24, unique = true)
    private String phone; //ex. 012-345-6789

    /** The email of Publisher **/
    @Column(nullable = false, length = 80, unique = true)
    private String email;

    /** The constructor for Publisher **/
    public Publishers(String name, String phone, String email)
    {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    /** Default constructor for Publisher **/
    public Publishers() {}

    /** retrieve the name of Publisher **/
    public String getName() { return name; }

    /** set the name of Publisher **/
    public void setName(String name) { this.name = name; }

    /** retrieve the phone number of Publisher **/
    public String getPhone() { return phone; }

    /** set the phone number of Publisher **/
    public void setPhone(String phone) { this.phone = phone; }

    /** retrieve the email of Publisher **/
    public String getEmail() { return email; }

    /** set the email of Publisher **/
    public void setEmail(String email) { this.email = email; }

    /** toString function for Publisher to display all attributes **/
    @Override
    public String toString()
    {
        return "Name: " + this.name + ", Phone: " + this.phone + ", Email: " + this.email;
    }
}
