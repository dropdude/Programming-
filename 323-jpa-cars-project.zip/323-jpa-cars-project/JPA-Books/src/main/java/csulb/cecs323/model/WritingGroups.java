/**
 Writing Groups class for Authoring Entity
 Homework Assignment: JPA - Books
 @author Frank Mancia, Jett Sonoda, Eric Nguyen
 @version 1.01 03/25/2022
 */
package csulb.cecs323.model;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;

@Entity
@DiscriminatorColumn ( name = "WG" )
/**
 * 2 or more individuals that identify as a group who write as an Authoring Entity
 */
public class WritingGroups extends AuthoringEntities
{
    /** Constructor for Writing Group, extends to AuthoringEntities **/
    public WritingGroups(String name, String email, String head_writer, int year_formed)
    {
        super(name, email, head_writer, year_formed);
    }

    /** Writing Groups default constructor **/
    public WritingGroups () { }

    /** toString function used for Writing Groups **/
    @Override
    public String toString()
    {
        return super.toString() + " Head Writer: " + this.getHead_writer() + " Year Formed: " + this.getYear_formed();
    }
}
